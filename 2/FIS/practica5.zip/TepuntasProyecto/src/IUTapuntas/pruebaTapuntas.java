/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IUTapuntas;

import ModeloTapuntas.Tapuntas;
import ModeloTapuntas.TipoTransaccion;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 *
 * @author aanaya
 */
public class pruebaTapuntas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     
        // Obtener la única instancia de la clase Tapuntas (patrón sigleton)
        Tapuntas aViajar = Tapuntas.getInstance(); 
        
        // Definir la variable que nos permite leer String desde teclado
        final Scanner in = new Scanner(System.in);
        int opcion = 0; 
        do{
            try{ // tratamiento de las excepciones. Bloque try en el que se puede producir una excepción y la capturamos
		 
                 //Terminar de diseñar el menú (usando System.out.println(...)) con las opciones que faltan
		 // Podéis hacer vuestros propios diseños de interfaz, esta es la interfaz mínima que tenéis que entregar
                System.out.println("\n\n*********************************** MENU ***********************************\n" +
                                       "GESTIÓN DE USUARIOS   \n" +
                                     "\t10. Nuevo Usuario \n" +
                                     "\t11. Consultar usuarios del sistema \n" +
                                     "\t12. Incluir Perfil de Usuario \n" +
                                     "\t13. Consultar Perfil de un Usuario \n");	
                                 
                System.out.println("GESTIÓN DE VEHICULOS  \n" +                             
                                    "\t20. Nuevo vehículo \n" +
                                    "\t21. Consultar vehículos de un usuario \n" +
                                    "\t22. Eliminar vehículo\n");
                
                System.out.println("GESTIÓN DE PLANES DE ALQUILER  \n" +
                                    "\t30. Definir nuevo plan de alquiler \n" +
                                    "\t31. Consultar mis planes de alquiler\n" +
                                    "\t32. Ofertar un plan de alquiler \n" +
                                    "\t33. Buscar ofertas de planes de alquiler \n");
                
                System.out.println("\n**********************************************************************");
                		         
                System.out.println("\t0. TERMINAR");
		System.out.println("\n**********************************************************************");
                 
                // Lectura de un int, para darle valor a opcion.
                opcion =Integer.parseInt(in.nextLine()); 
                
                // Estructura switch con todas las opciones de menú. Algunos de ellos ya lo tenéis hecho
                // Tenéis que terminar las opciones que están incompletas y las que no están hechas
                switch(opcion){
                    case 10: //incluir un nuevo usuario en el sistema 
                                            
                        System.out.print("Nombre de Usuario: ");
                        String nombreUsuario = in.nextLine();
                                       
                        System.out.print("Clave: ");
                        String claveUsuario = in.nextLine();
                        
                        System.out.print("Dirección de correo: ");
                        String correoUsuario = in.nextLine();
                        
                        aViajar.altaRegistro(nombreUsuario, claveUsuario, correoUsuario);                                             
                        System.out.print("++++++  Operación realizada con éxito ++++++");
                    break;  
                    
                    case 11:/*Ver usuarios del sistema */
                        ArrayList<String> misUsuarios = aViajar.obtenerUsuarios();
                        misUsuarios.stream().forEach((usuario) -> {
                            System.out.println(usuario);
                });
                    break;
                    
                    case 12:/*Incluir Perfil */
                        ArrayList<TipoTransaccion> preferenciasCobro = new ArrayList();
                        String sino;
                        System.out.print("Nombre de Usuario: ");
                        nombreUsuario = in.nextLine();
                        System.out.print("Nombre: ");
                        String nombre = in.nextLine();
                        System.out.print("Teléfono: ");
                        String telefono = in.nextLine();
                        System.out.print("Introduzca una breve descripción: ");
                        String breveDesc = in.nextLine();
                        
                        int contador = 0;
                        
                        do {
                        System.out.print("¿Es tarjeta un sistema de cobro preferido? (s/n)");
                        sino = in.nextLine();
                        } while (!sino.equals("s") && !sino.equals("n"));
                        
                        if (sino.equals("s")) {
                            preferenciasCobro.add(TipoTransaccion.TARJETA);
                            ++contador;
                        }
                        sino = "";
                        
                        do {
                        System.out.print("¿Es PayPal un sistema de cobro preferido? (s/n)");
                        sino = in.nextLine();
                        } while (!sino.equals("s") && !sino.equals("n"));
                        if (sino.equals("s")) {
                            preferenciasCobro.add(TipoTransaccion.PAYPAL);
                            ++contador;
                        }
                        sino = "";
                        
                        do {
                        System.out.print("¿Es efectivo un sistema de cobro preferido? (s/n)");
                        sino = in.nextLine();
                        } while (!sino.equals("s") && !sino.equals("n"));
                        if (sino.equals("s")) {
                            preferenciasCobro.add(TipoTransaccion.EFECTIVO);
                            ++contador;
                        }
                        sino = "";
                        
                        do {
                        System.out.print("¿Es transferencia un sistema de cobro preferido? (s/n)");
                        sino = in.nextLine();
                        } while (!sino.equals("s") && !sino.equals("n"));
                        if (sino.equals("s")) {
                            preferenciasCobro.add(TipoTransaccion.TRANSFERENCIA);
                            ++contador;
                        }
                        
                        if (contador == 0) throw new Exception("Debe selecionar al menos un sistema de cobro preferido");
                        
                        aViajar.introducirPerfil(nombreUsuario, nombre, telefono, breveDesc, preferenciasCobro);
                        System.out.print("++++++  Operación realizada con éxito ++++++");                     
                    break;
                    case 13:/*Consultar perfil */
                        System.out.print("Nombre de Usuario: ");
                        nombreUsuario = in.nextLine();
                        // TO-CHECK
                        ArrayList<String> miPerfil = aViajar.consultarPerfil(nombreUsuario);
                        System.out.println("Nombre: "                     + ((miPerfil.get(0)==null) ? "" : miPerfil.get(0)));
                        System.out.println("Teléfono: "                   + ((miPerfil.get(1)==null) ? "" : miPerfil.get(1)));
                        System.out.println("Breve descripción personal: " + ((miPerfil.get(2)==null) ? "" : miPerfil.get(2)));
                        System.out.println("Visibilidad del perfil: "     +   miPerfil.get(3));
                        System.out.print("++++++  Operación realizada con éxito ++++++");    
                    break;
                
                    case 20: /*Nuevo vehículo */
                        System.out.print("Nombre de Usuario: ");
                        nombreUsuario = in.nextLine();  
                        System.out.print("Matricula: ");
                        String matricula = in.nextLine();
                        System.out.print("Marca: ");
                        String marca = in.nextLine();
                        System.out.print("Modelo: ");
                        String modelo = in.nextLine();
                        System.out.print("Color: ");
                        String color = in.nextLine();
                        System.out.print("Número de Plazas: ");
                        int plazas = Integer.parseInt(in.nextLine()); 
                        System.out.print("Categoría: ");
                        String categoria= in.nextLine();
                        System.out.print("Confor: ");
                        String confor = in.nextLine();
                        aViajar.añadirVehiculo(nombreUsuario, matricula, marca, modelo, color, plazas, categoria, confor);
                        System.out.print("++++++  Operación realizada con éxito ++++++");
                                                     
                    break;
                  
                    case 21: /* Consultar vehículos de un usuario  */
                        System.out.print("Nombre de Usuario: ");
                        nombreUsuario = in.nextLine(); 
                        ArrayList<ArrayList<String>> misVehiculos = aViajar.obtenerVehiculos(nombreUsuario);
                        for (ArrayList<String> datos : misVehiculos) {
                            System.out.println("");
                            System.out.println("Matricula: "        + datos.get(0));
                            System.out.println("Marca: "            + datos.get(1));
                            System.out.println("Modelo: "           + datos.get(2));
                            System.out.println("Confor: "           + datos.get(3));
                            System.out.println("Número de plazas: " + datos.get(4));
                            System.out.println("Color: "            + datos.get(5));
                            System.out.println("Categoría: "        + datos.get(6));
                        }
                        System.out.print("++++++  Operación realizada con éxito ++++++");
                    break;             
                  
                    case 22: /* Eliminar vehículo  */
                        System.out.print("Nombre de Usuario: ");
                        nombreUsuario = in.nextLine();  
                        System.out.print("Matricula: ");
                        matricula = in.nextLine();
                        aViajar.eliminarVehículoPropietario(nombreUsuario, matricula);
                        System.out.print("++++++  Operación realizada con éxito ++++++");
                    break;
  
    
                    case 30: /* Nuevo plan de alquiler */
                         System.out.print("Nombre de Usuario: ");
                         nombreUsuario = in.nextLine();
                         System.out.print("Matricula: ");
                         matricula = in.nextLine();
                         System.out.println("FECHA INICIO(introducir en formato numérico)");
                         System.out.print("dia: ");
                         int dia = Integer.parseInt(in.nextLine());
                         System.out.print("mes: ");
                         int mes = Integer.parseInt(in.nextLine());
                         System.out.print("año: ");
                         int año = Integer.parseInt(in.nextLine());
                         System.out.print("hora: ");
                         int hora = Integer.parseInt(in.nextLine());
                         System.out.print("minuto: ");
                         int minuto = Integer.parseInt(in.nextLine());
                         GregorianCalendar fechaInicio = new GregorianCalendar(año, mes - 1, dia, hora, minuto);
                         System.out.println("FECHA FIN(introducir en formato numérico)");
                         System.out.print("dia: ");
                         dia = Integer.parseInt(in.nextLine());
                         System.out.print("mes: ");
                         mes = Integer.parseInt(in.nextLine());
                         System.out.print("año: ");
                         año = Integer.parseInt(in.nextLine());
                         System.out.print("hora: ");
                         hora = Integer.parseInt(in.nextLine());
                         System.out.print("minuto: ");
                         minuto = Integer.parseInt(in.nextLine());
                         GregorianCalendar fechaFin = new GregorianCalendar(año, mes - 1, dia, hora, minuto);
                         System.out.print("Ciudad recogida: ");
                         String ciudad = in.nextLine();
                         System.out.print("Coste alquiler diario: ");
                         double costeDiario = Double.parseDouble(in.nextLine());
                         
                         aViajar.definirPlanAlquiler(nombreUsuario, matricula, fechaInicio, fechaFin, ciudad, costeDiario);
                         System.out.print("++++++  Operación realizada con éxito ++++++");

                    break;

                    case 31: /* Consultar planes de alquiler de un usuario */
                       System.out.print("Nombre de Usuario: ");
                       nombreUsuario = in.nextLine(); 
                       
                       for (ArrayList<String> oferta : aViajar.obtenerPlanesAlquiler(nombreUsuario)) {
                           System.out.println("");
                           System.out.println("Matricula: "             + oferta.get(0));
                           System.out.println("Primer día alquiler: "   + oferta.get(1));
                           System.out.println("Último día alquiler: "   + oferta.get(2));
                           System.out.println("Coste alquiler al día: " + oferta.get(3));
                           System.out.println("Ciudad de recogida: "    + oferta.get(4));
                       }
                       System.out.print("++++++  Operación realizada con éxito ++++++");
                       
                    break;

                    case 32: /* Ofertar un plan de alquiler */
                         System.out.print("Nombre de Usuario: ");
                         nombreUsuario = in.nextLine();
                         System.out.print("Matricula: ");
                         matricula = in.nextLine();
                         System.out.println("FECHA INICIO PLAN(introducir en formato numérico)");
                         System.out.print("dia: ");
                         dia = Integer.parseInt(in.nextLine());
                         System.out.print("mes: ");
                         mes = Integer.parseInt(in.nextLine());
                         System.out.print("año: ");
                         año = Integer.parseInt(in.nextLine());
                         System.out.print("hora: ");
                         hora = Integer.parseInt(in.nextLine());
                         System.out.print("minuto: ");
                         minuto = Integer.parseInt(in.nextLine());
                         fechaInicio = new GregorianCalendar(año, mes - 1, dia, hora, minuto);
                         
                         aViajar.ofertarPlanAlquiler(nombreUsuario, fechaInicio, matricula);
                         System.out.print("++++++  Operación realizada con éxito ++++++");
                    break;

                    case 33: /* Buscar ofertas de planes de alquiler  */
                         System.out.print("Ciudad recogida: ");
                         ciudad = in.nextLine();
                         System.out.println("FECHA INICIO(introducir en formato numérico)");
                         System.out.print("dia: ");
                         dia = Integer.parseInt(in.nextLine());
                         System.out.print("mes: ");
                         mes = Integer.parseInt(in.nextLine());
                         System.out.print("año: ");
                         año = Integer.parseInt(in.nextLine());
                         System.out.print("hora: ");
                         hora = Integer.parseInt(in.nextLine());
                         System.out.print("minuto: ");
                         minuto = Integer.parseInt(in.nextLine());
                         fechaInicio = new GregorianCalendar(año, mes - 1, dia, hora, minuto);
                         System.out.println("FECHA FIN(introducir en formato numérico)");
                         System.out.print("dia: ");
                         dia = Integer.parseInt(in.nextLine());
                         System.out.print("mes: ");
                         mes = Integer.parseInt(in.nextLine());
                         System.out.print("año: ");
                         año = Integer.parseInt(in.nextLine());
                         System.out.print("hora: ");
                         hora = Integer.parseInt(in.nextLine());
                         System.out.print("minuto: ");
                         minuto = Integer.parseInt(in.nextLine());
                         fechaFin = new GregorianCalendar(año, mes - 1, dia, hora, minuto);
                         
                         ArrayList<ArrayList<String>> ofertas = aViajar.buscarOfertasAlquiler(ciudad, fechaInicio, fechaFin);
                         for (ArrayList<String> oferta : ofertas) {
                             System.out.println("");
                             System.out.println("Nombre: "           +((oferta.get(0)==null) ? "Desconocido" : oferta.get(0)));
                             System.out.println("TipoTransaccion: "  +  oferta.get(1));
                             System.out.println("Precio: "           +  oferta.get(2));
                             System.out.println("Matricula: "        +  oferta.get(3));
                             System.out.println("Marca: "            +  oferta.get(4));
                             System.out.println("Modelo: "           +  oferta.get(5));
                             System.out.println("Confor: "           +  oferta.get(6));
                             System.out.println("Número de Plazas: " +  oferta.get(7));
                             System.out.println("Color: "            +  oferta.get(8));
                             System.out.println("Categoría: "        +  oferta.get(9));
                         }
                         System.out.print("++++++  Operación realizada con éxito ++++++");
                    break;                 

                    case 0: /* terminar */
                    break;                        
                                    
                    default:
                        System.out.println("opcion no válida");
                    break;
                }
//               
            }catch(Exception ex){ // captura de la excepción
                System.err.println("se ha producido la siguiente excepcion: "+ ex);
            } 
        }while(opcion !=0); 
        System.exit(0);
    }  

}

    
    

