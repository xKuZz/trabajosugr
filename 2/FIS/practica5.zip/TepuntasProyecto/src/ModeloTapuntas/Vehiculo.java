/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloTapuntas;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

/**
 *
 * @author xKuZz
 */
public class Vehiculo {
    private String marca;
    private String modelo;
    private String confor;
    private int numeroPlazas;
    private String color;
    private String categoria;
    private String matricula;
    private HashMap<GregorianCalendar, PlanAlquiler> misPlanes = new HashMap();
    
    Vehiculo(Usuario unUsuario, String matricula, String marca, String modelo,
            String color, int numeroPlazas, String categoria, String confor) {
        this.marca = marca;
        this.modelo = modelo;
        this.confor = confor;
        this.numeroPlazas = numeroPlazas;
        this.color = color;
        this.categoria = categoria;
        this.matricula = matricula;
    }
    
    ArrayList<String> obtenerDatosVehiculo() {
      ArrayList<String> misDatos = new ArrayList();
      misDatos.add(matricula);
      misDatos.add(marca);
      misDatos.add(modelo);
      misDatos.add(confor);
      misDatos.add(Integer.toString(numeroPlazas));
      misDatos.add(color);
      misDatos.add(categoria);
      return misDatos;
    }
    
    boolean estasDisponible(GregorianCalendar fechaInicio, 
                            GregorianCalendar fechaFin) {
      for (GregorianCalendar clave : misPlanes.keySet()) {
          PlanAlquiler plan = misPlanes.get(clave);
          if (fechaInicio.compareTo(plan.primerDiaAlquiler()) >= 0 &&
                 fechaFin.compareTo(plan.ultimoDiaAlquiler()) <= 0)
              return false;   
      }
      return true;
    }
    
    void incluirPlanAlquiler(PlanAlquiler pa) {
        misPlanes.put(pa.primerDiaAlquiler(), pa);
    }
    
    boolean comprobarEstadoAlquileres() {
        for (GregorianCalendar clave : misPlanes.keySet()) {
          PlanAlquiler plan = misPlanes.get(clave);
          GregorianCalendar ahora = new GregorianCalendar();
          if (plan.primerDiaAlquiler().compareTo(ahora) <= 0 &&
              plan.ultimoDiaAlquiler().compareTo(ahora) >= 0)
              return true;
        }
        return false;
        // WARNING: Cuando se añadan los alquileres el método devolverá true
        // si FECHA_ACTUAL < primerDiaAlquiler y el hay un objetoAlquiler aceptado
    }
    
    void eliminarVehiculoAlquileres() {
        for (GregorianCalendar clave : misPlanes.keySet()) {
          PlanAlquiler pa = misPlanes.get(clave);
          pa.eliminarVehiculo();
        }
    }

    String obtenerMatricula() {
       return matricula;
    }
}
