/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloTapuntas;

import java.util.ArrayList;

/**
 *
 * @author xKuZz
 */
public enum TipoTransaccion {
    TARJETA,
    PAYPAL,
    EFECTIVO,
    TRANSFERENCIA;
    
    public static String toString(TipoTransaccion t) {
        if (t == TipoTransaccion.TARJETA)
            return "Tarjeta";
        else if (t == TipoTransaccion.PAYPAL)
            return "Paypal";
        else if (t == TipoTransaccion.EFECTIVO)
            return "Efectivo";
        else
            return "Transferencia";
    }
    
    public static String toString(ArrayList<TipoTransaccion> t) {
        String s = "";
        for (TipoTransaccion tipo : t)
            s+= TipoTransaccion.toString(tipo) + " ";
        return s;             
    }
    
}

