/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloTapuntas;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;

/**
 *
 * @author xKuZz
 */
public class PlanAlquiler {
    private boolean visible;
    private GregorianCalendar primerDiaAlquiler;
    private GregorianCalendar ultimoDiaAlquiler;
    private double costeAlquilerAlDia;
    private String ciudadRecogida;
    private Vehiculo miVehiculo;
    
    PlanAlquiler(Vehiculo unVehiculo, GregorianCalendar fechaInicio,
                 GregorianCalendar fechaFin, String ciudadRecogida, double coste) {
        this.miVehiculo = unVehiculo;
        this.primerDiaAlquiler = fechaInicio;
        this.ultimoDiaAlquiler = fechaFin;
        this.ciudadRecogida = ciudadRecogida;
        this.costeAlquilerAlDia = coste;
        this.modificarVisibilidad(false);
    }
    ArrayList<String> obtenerDatosPA() {
        ArrayList<String> datosPA = miVehiculo.obtenerDatosVehiculo();
        datosPA.add(0, Double.toString(costeAlquilerAlDia));
        return datosPA;
    }
    
    void eliminarVehiculo() {
        miVehiculo = null;
    }
    
    ArrayList<String> obtenerDatosPlanAlquiler() {
        ArrayList<String> datosPlanAlquiler = new ArrayList();
        String matricula = miVehiculo.obtenerMatricula();
        datosPlanAlquiler.add(matricula);
        DateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        datosPlanAlquiler.add(formatoFecha.format(primerDiaAlquiler.getTime()));
        datosPlanAlquiler.add(formatoFecha.format(ultimoDiaAlquiler.getTime()));
        datosPlanAlquiler.add(Double.toString(costeAlquilerAlDia));
        datosPlanAlquiler.add(ciudadRecogida);
        return datosPlanAlquiler;
    }
    
    void modificarVisibilidad(boolean visible){
        this.visible = visible;
    }
    
    String ciudadRecogida() {
        return ciudadRecogida;
    }
    
    GregorianCalendar primerDiaAlquiler() {
        return primerDiaAlquiler;
    }
    
    GregorianCalendar ultimoDiaAlquiler() {
        return ultimoDiaAlquiler;
    }
    
    boolean visible() {
        return visible;
    }
    
    boolean vigente() {
        GregorianCalendar ahora = new GregorianCalendar();
        return primerDiaAlquiler.compareTo(ahora) <= 0 && ultimoDiaAlquiler.compareTo(ahora) >= 0;
    }
    
}
