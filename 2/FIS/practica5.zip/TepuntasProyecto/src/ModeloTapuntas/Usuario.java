/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModeloTapuntas;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;

/**
 *
 * @author aanaya
 */
class Usuario {

    private String nombreUsuario;
    private String contraseña;
    private String direccionCorreo;
    private boolean visibilidad = false;
    private boolean pendienteBaja = false;
    // incluir los demás atributos
    private String nombre;
    private String telefono;
    private String breveDescripcionPersonal;
    private ArrayList<TipoTransaccion> preferenciaCobro = new ArrayList();
    // El ArrayList de Object contien la tupla Matricula, fechaInicio
    private HashMap<ArrayList<Object>, PlanAlquiler> misPlanes = new HashMap();
    private HashMap<String, Vehiculo> misVehiculos = new HashMap();

    Usuario(String nombreUsuario, String contraseña, String direccionCorreo) {
        this.nombreUsuario = nombreUsuario;
        this.contraseña = contraseña;
        this.direccionCorreo = direccionCorreo;
    }

    void modificarVisibilidad(boolean visibilidad) {
        this.visibilidad = visibilidad;
    }

    void nuevoVehiculo(String matricula, String marca, String modelo,
            String color, int numeroPlazas, String categoria, String confor) {
        Vehiculo unVehiculo = new Vehiculo(this, matricula, marca, modelo, color,
                numeroPlazas, categoria, confor);
        misVehiculos.put(matricula, unVehiculo);
    }

    ArrayList<ArrayList<String>> obtenerPlanesQueCumplanRequisitos(String ciudadRecogida,
            GregorianCalendar fechaInicio, GregorianCalendar fechaFin) {
        ArrayList<ArrayList<String>> datosPAUsuario = new ArrayList();
        for (ArrayList<Object> clave : misPlanes.keySet()) {
            PlanAlquiler pa = misPlanes.get(clave);
            if (ciudadRecogida.equals(pa.ciudadRecogida()) && fechaInicio.compareTo(pa.primerDiaAlquiler()) >= 0
                    && fechaFin.compareTo(pa.ultimoDiaAlquiler()) <= 0) {
                ArrayList<String> datosPA = pa.obtenerDatosPA();
                datosPA.add(0,TipoTransaccion.toString(preferenciaCobro));
                datosPA.add(0,nombre);  
                datosPAUsuario.add(datosPA);
            }
        }
        return datosPAUsuario;
    }

    void definirPlanAlquiler(String matricula, GregorianCalendar fechaInicio,
            GregorianCalendar fechaFin, String ciudadRecogida, double coste) throws Exception {
        Vehiculo vehiculo = buscarVehiculo(matricula);
        boolean disponible = vehiculo.estasDisponible(fechaInicio, fechaFin);
        if (!disponible) {
            throw new Exception("el vehiculo ya pertenece plan alquiler en esas fechas");
        }
        PlanAlquiler miPlanAlquiler = new PlanAlquiler(vehiculo, fechaInicio, fechaFin, ciudadRecogida, coste);
        vehiculo.incluirPlanAlquiler(miPlanAlquiler);
        ArrayList<Object> clave = new ArrayList();
        clave.add(matricula);
        clave.add(fechaInicio);
        misPlanes.put(clave, miPlanAlquiler);
    }

    void eliminarVehiculo(String matricula) throws Exception {
        Vehiculo vehiculo = buscarVehiculo(matricula);
        boolean alquilado = vehiculo.comprobarEstadoAlquileres();
        if (alquilado) {
            throw new Exception("el vehiculo no se puede eliminar, tiene vigentes alquileres o viajes");
        } else {
            vehiculo.eliminarVehiculoAlquileres();
        }
        misVehiculos.remove(matricula);
    }

    void introducirPerfil(String nombre, String telefono, String breveDesc,
            ArrayList<TipoTransaccion> preferenciaCobro) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.breveDescripcionPersonal = breveDesc;
        this.preferenciaCobro = preferenciaCobro;
        this.modificarVisibilidad(true);
    }

    ArrayList<ArrayList<String>> obtenerPlanesAlquiler() {
        ArrayList<ArrayList<String>> misPlanesAlquiler = new ArrayList();
        for (ArrayList<Object> clave : misPlanes.keySet()) {
            PlanAlquiler pa = misPlanes.get(clave);
            if (!pa.visible() && pa.vigente()) {
                ArrayList<String> datosPlanAlquiler = pa.obtenerDatosPlanAlquiler();
                misPlanesAlquiler.add(datosPlanAlquiler);
            }
        }
        return misPlanesAlquiler;
    }

    ArrayList<String> consultarPerfil() {
        ArrayList<String> infoPerfil = new ArrayList();
        infoPerfil.add(nombre);
        infoPerfil.add(telefono);
        infoPerfil.add(breveDescripcionPersonal);
        if (visibilidad == true) {
            infoPerfil.add("visible");
        } else {
            infoPerfil.add("no visible");
        }
        return infoPerfil;
    }

    void ofertarPlanAlquiler(GregorianCalendar fechaInicio, String matricula) throws Exception {
        PlanAlquiler pa = this.buscarPlanAlquiler(matricula, fechaInicio);
        pa.modificarVisibilidad(true);
    }

    boolean tienePerfilDefinido() {
        return nombre != null;
    }

    ArrayList<ArrayList<String>> obtenerVehiculos() {
        ArrayList<ArrayList<String>> datosVehiculos = new ArrayList();
        for (String matricula : misVehiculos.keySet()) {
            Vehiculo unVehiculo = misVehiculos.get(matricula);
            datosVehiculos.add(unVehiculo.obtenerDatosVehiculo());
        }
        return datosVehiculos;
    }

    boolean existeVehiculo(String matricula) {
        return misVehiculos.containsKey(matricula);
    }

    private Vehiculo buscarVehiculo(String matricula) throws Exception {
        Vehiculo vehiculo = misVehiculos.get(matricula);
        if (vehiculo == null) {
            throw new Exception("El usuario no posee un vehiculo con dicha matricula");
        } else {
            return vehiculo;
        }
    }

    private PlanAlquiler buscarPlanAlquiler(String matricula, GregorianCalendar fechaInicio) throws Exception {
        ArrayList<Object> clave = new ArrayList();
        clave.add(matricula);
        clave.add(fechaInicio);
        PlanAlquiler pa = misPlanes.get(clave);
        if (pa == null) {
            throw new Exception("El usuario no tiene el plan de alquiler especificado");
        } else {
            return pa;
        }
    }

}
