var searchData=
[
  ['fecha',['fecha',['../classfecha.html#a6775ef84b5838e12e28fd341793f4539',1,'fecha::fecha()'],['../classfecha.html#affbc58390398cbbc117bdfa754b0cd35',1,'fecha::fecha(const fecha &amp;F)'],['../classfecha.html#aed5c22d5eeb15f1f2927d5a2c28b74df',1,'fecha::fecha(const string &amp;s)']]],
  ['find_5fid',['find_ID',['../class_c_s_s.html#ae43eefb92e0e6f4a9390350a427655c4',1,'CSS']]]
];
