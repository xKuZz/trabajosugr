var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classfecha.html#a9787de38b43ae62ba2c0812f3dd18394',1,'fecha::operator&lt;&lt;()'],['../classcrimen.html#a4984d9a6773993c33ba40b80b3c09c72',1,'crimen::operator&lt;&lt;()']]]
];
