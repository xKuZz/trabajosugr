var searchData=
[
  ['crimen',['crimen',['../classcrimen.html#ab1147e36869c7e635699e4ef746a7555',1,'crimen::crimen()'],['../classcrimen.html#a50b783e821c2f5bc829eceb9048c12d7',1,'crimen::crimen(const crimen &amp;x)']]]
];
