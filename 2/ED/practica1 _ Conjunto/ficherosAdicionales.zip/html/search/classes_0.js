var searchData=
[
  ['conjunto',['conjunto',['../classconjunto.html',1,'']]],
  ['crimen',['crimen',['../classcrimen.html',1,'']]]
];
