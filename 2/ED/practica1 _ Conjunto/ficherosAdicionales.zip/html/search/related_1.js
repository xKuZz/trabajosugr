var searchData=
[
  ['diccionario',['diccionario',['../classconjunto_1_1description__iterator.html#a44955070f60117521fa6b406a83e6d4d',1,'conjunto::description_iterator']]]
];
