var searchData=
[
  ['id',['ID',['../classcrimen.html#a59702f88f0b0c25781ae3d296790dcb8',1,'crimen']]],
  ['insert',['insert',['../classconjunto.html#aa65b9f7c4cb9bad6d4e40c1973095930',1,'conjunto']]],
  ['iucr',['IUCR',['../classcrimen.html#a064e0e02109feaea19f254ef47a2510c',1,'crimen']]]
];
