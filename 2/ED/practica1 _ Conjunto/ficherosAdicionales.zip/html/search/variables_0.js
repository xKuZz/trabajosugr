var searchData=
[
  ['arrest',['arrest',['../classcrimen.html#aaca016db0de1f4fca947dff8f5b57eb6',1,'crimen']]]
];
