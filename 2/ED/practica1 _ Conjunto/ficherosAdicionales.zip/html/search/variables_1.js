var searchData=
[
  ['case_5fnumber',['case_number',['../classcrimen.html#a1c6d897810ce4bf6229b0a5b473f80d2',1,'crimen']]]
];
