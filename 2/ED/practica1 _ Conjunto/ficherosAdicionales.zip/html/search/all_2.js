var searchData=
[
  ['date',['date',['../classcrimen.html#ab3ef462c5da98dbf03142c06e8c1a099',1,'crimen']]],
  ['description',['description',['../classcrimen.html#aad80606e3a0a9ec03c2d2d082900055b',1,'crimen']]],
  ['documentacion_2edox',['documentacion.dox',['../documentacion_8dox.html',1,'']]],
  ['domestic',['domestic',['../classcrimen.html#ab4112133af2623da7a272e73845348db',1,'crimen']]],
  ['documentación_20práctica',['Documentación Práctica',['../index.html',1,'']]]
];
