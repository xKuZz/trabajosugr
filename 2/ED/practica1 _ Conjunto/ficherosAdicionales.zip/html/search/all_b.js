var searchData=
[
  ['primary_5ftype',['primary_type',['../classcrimen.html#ae6d5de0ba61dbebb13b78d0010907467',1,'crimen']]],
  ['principal_2ecpp',['principal.cpp',['../principal_8cpp.html',1,'']]]
];
