var searchData=
[
  ['latitude',['latitude',['../classcrimen.html#a1ecd1bcebba3566f13a469ec82f647a0',1,'crimen']]],
  ['load',['load',['../principal_8cpp.html#ace66e6613caeee9e4eff28e999a58da1',1,'principal.cpp']]],
  ['location',['location',['../classcrimen.html#acca87eb25a97e33dad2346209bee3c91',1,'crimen']]],
  ['longitude',['longitude',['../classcrimen.html#ac140577426c2a38d58ec1907bce53492',1,'crimen']]]
];
