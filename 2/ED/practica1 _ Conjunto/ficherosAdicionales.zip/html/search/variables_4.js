var searchData=
[
  ['id',['ID',['../classcrimen.html#a59702f88f0b0c25781ae3d296790dcb8',1,'crimen']]],
  ['iucr',['IUCR',['../classcrimen.html#a064e0e02109feaea19f254ef47a2510c',1,'crimen']]]
];
