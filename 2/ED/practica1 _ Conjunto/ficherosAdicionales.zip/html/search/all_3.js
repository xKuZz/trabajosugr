var searchData=
[
  ['empty',['empty',['../classconjunto.html#afcf4ff3ff3c1f83b63e901efebe93533',1,'conjunto']]],
  ['entrada',['entrada',['../classconjunto.html#a09cad766dd65de73e51eae21f9d22585',1,'conjunto']]],
  ['erase',['erase',['../classconjunto.html#ad550177fa4454da3a10fa356417e39a7',1,'conjunto::erase(const long int &amp;id)'],['../classconjunto.html#a77a21ed91f1002f4eaed48d86535a874',1,'conjunto::erase(const conjunto::entrada &amp;e)']]]
];
