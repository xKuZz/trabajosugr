var searchData=
[
  ['vc',['vc',['../classconjunto.html#aed485e92bb3d8b2c82fc85657947761d',1,'conjunto']]]
];
