var searchData=
[
  ['difference_5ftype',['difference_type',['../classconjunto_1_1const__description__iterator.html#a1fffe8d19ea3bafd368799f551c3c91b',1,'conjunto::const_description_iterator']]]
];
