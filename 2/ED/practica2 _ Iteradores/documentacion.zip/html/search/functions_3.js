var searchData=
[
  ['dbegin',['dbegin',['../classconjunto.html#acd209e7626973fd13c07da2e51675923',1,'conjunto']]],
  ['dend',['dend',['../classconjunto.html#ade7f369233cc161a33d6136f1a1323fc',1,'conjunto']]],
  ['description_5fiterator',['description_iterator',['../classconjunto_1_1description__iterator.html#a2aecc33a859c4f8a83265c5867dcac8b',1,'conjunto::description_iterator::description_iterator()'],['../classconjunto_1_1description__iterator.html#af211c5428de96fa6f7da7dff6890d2f6',1,'conjunto::description_iterator::description_iterator(const description_iterator &amp;it)']]]
];
