var searchData=
[
  ['date',['date',['../classcrimen.html#ab3ef462c5da98dbf03142c06e8c1a099',1,'crimen']]],
  ['dbegin',['dbegin',['../classconjunto.html#acd209e7626973fd13c07da2e51675923',1,'conjunto']]],
  ['dend',['dend',['../classconjunto.html#ade7f369233cc161a33d6136f1a1323fc',1,'conjunto']]],
  ['descr',['descr',['../classconjunto_1_1description__iterator.html#a3af23f14ec44378308e577ba8c9c71e0',1,'conjunto::description_iterator::descr()'],['../classconjunto_1_1const__description__iterator.html#a46a1e768efcf3886d1ab9063b76dcbe7',1,'conjunto::const_description_iterator::descr()']]],
  ['description',['description',['../classcrimen.html#aad80606e3a0a9ec03c2d2d082900055b',1,'crimen']]],
  ['description_5fiterator',['description_iterator',['../classconjunto.html#a1f956dc6494785c3139e78f0461a0d79',1,'conjunto::description_iterator()'],['../classconjunto_1_1description__iterator.html#a2aecc33a859c4f8a83265c5867dcac8b',1,'conjunto::description_iterator::description_iterator()'],['../classconjunto_1_1description__iterator.html#af211c5428de96fa6f7da7dff6890d2f6',1,'conjunto::description_iterator::description_iterator(const description_iterator &amp;it)']]],
  ['description_5fiterator',['description_iterator',['../classconjunto_1_1description__iterator.html',1,'conjunto']]],
  ['difference_5ftype',['difference_type',['../classconjunto_1_1const__description__iterator.html#a1fffe8d19ea3bafd368799f551c3c91b',1,'conjunto::const_description_iterator']]],
  ['domestic',['domestic',['../classcrimen.html#ab4112133af2623da7a272e73845348db',1,'crimen']]]
];
