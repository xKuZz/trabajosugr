var searchData=
[
  ['id',['ID',['../classcrimen.html#a59702f88f0b0c25781ae3d296790dcb8',1,'crimen']]],
  ['itv',['itv',['../classconjunto_1_1iterator.html#a5bd607fdec49c2ab132859bf922e2db6',1,'conjunto::iterator::itv()'],['../classconjunto_1_1arrest__iterator.html#af4f40f57ec83f9c6b199ed70a1a88d07',1,'conjunto::arrest_iterator::itv()'],['../classconjunto_1_1description__iterator.html#ac4c653cecb7c8076a40338775b2b911b',1,'conjunto::description_iterator::itv()']]],
  ['iucr',['IUCR',['../classcrimen.html#a064e0e02109feaea19f254ef47a2510c',1,'crimen']]]
];
