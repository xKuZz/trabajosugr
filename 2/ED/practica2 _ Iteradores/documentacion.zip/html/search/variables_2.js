var searchData=
[
  ['date',['date',['../classcrimen.html#ab3ef462c5da98dbf03142c06e8c1a099',1,'crimen']]],
  ['descr',['descr',['../classconjunto_1_1description__iterator.html#a3af23f14ec44378308e577ba8c9c71e0',1,'conjunto::description_iterator::descr()'],['../classconjunto_1_1const__description__iterator.html#a46a1e768efcf3886d1ab9063b76dcbe7',1,'conjunto::const_description_iterator::descr()']]],
  ['description',['description',['../classcrimen.html#aad80606e3a0a9ec03c2d2d082900055b',1,'crimen']]],
  ['domestic',['domestic',['../classcrimen.html#ab4112133af2623da7a272e73845348db',1,'crimen']]]
];
