var searchData=
[
  ['c_5fitv',['c_itv',['../classconjunto_1_1const__iterator.html#a6ffe0c493b12aa9f40dc1501f0c904fc',1,'conjunto::const_iterator::c_itv()'],['../classconjunto_1_1const__arrest__iterator.html#a83b24bfb0d15cae1de2e597d035c1745',1,'conjunto::const_arrest_iterator::c_itv()'],['../classconjunto_1_1const__description__iterator.html#a276e0b3923f4e8a7c0c55abb0abeff90',1,'conjunto::const_description_iterator::c_itv()']]],
  ['case_5fnumber',['case_number',['../classcrimen.html#a1c6d897810ce4bf6229b0a5b473f80d2',1,'crimen']]]
];
