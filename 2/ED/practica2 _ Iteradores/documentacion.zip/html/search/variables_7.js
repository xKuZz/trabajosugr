var searchData=
[
  ['primary_5ftype',['primary_type',['../classcrimen.html#ae6d5de0ba61dbebb13b78d0010907467',1,'crimen']]],
  ['ptr',['ptr',['../classconjunto_1_1arrest__iterator.html#a44542d041fa7f6a2a4540d1280056ab9',1,'conjunto::arrest_iterator::ptr()'],['../classconjunto_1_1const__arrest__iterator.html#af997baa3ee94dc119d545dbc4f157aad',1,'conjunto::const_arrest_iterator::ptr()'],['../classconjunto_1_1description__iterator.html#a9f062870ed17e26652c97127bac17ad5',1,'conjunto::description_iterator::ptr()'],['../classconjunto_1_1const__description__iterator.html#adec198bc5efccdda45efe7afc3082d8a',1,'conjunto::const_description_iterator::ptr()']]]
];
