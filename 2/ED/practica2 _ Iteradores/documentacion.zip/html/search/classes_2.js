var searchData=
[
  ['description_5fiterator',['description_iterator',['../classconjunto_1_1description__iterator.html',1,'conjunto']]]
];
