var indexSectionsWithContent =
{
  0: "abcdefilnoprsu~",
  1: "abcilnp",
  2: "abcdefilnoprsu~",
  3: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Funciones",
  3: "Páginas"
};

