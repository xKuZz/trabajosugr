var searchData=
[
  ['id',['ID',['../classcrimen.html#a59702f88f0b0c25781ae3d296790dcb8',1,'crimen']]],
  ['insert',['insert',['../classconjunto.html#ab908ba4bc5923ce8617bd1003bcf08e9',1,'conjunto']]],
  ['iterator',['iterator',['../classconjunto_1_1iterator.html',1,'conjunto']]],
  ['iterator',['iterator',['../classconjunto.html#a67171474c4da6cc8efe0c7fafefd2b2d',1,'conjunto::iterator()'],['../classconjunto_1_1iterator.html#a3f22236830d397ec750b795e4358492d',1,'conjunto::iterator::iterator()'],['../classconjunto_1_1iterator.html#ae6ffce98c8835de978c7b8f0a769a1fe',1,'conjunto::iterator::iterator(const iterator &amp;it)']]],
  ['itv',['itv',['../classconjunto_1_1iterator.html#a670501cc6724497877d7a131efe50e60',1,'conjunto::iterator']]],
  ['iucr',['IUCR',['../classcrimen.html#a064e0e02109feaea19f254ef47a2510c',1,'crimen']]]
];
