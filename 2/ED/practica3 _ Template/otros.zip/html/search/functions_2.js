var searchData=
[
  ['empty',['empty',['../classconjunto.html#a904716d6ae739f0461880b08138cf4e4',1,'conjunto']]],
  ['end',['end',['../classconjunto.html#ab9be89e672032da4f0945663c76e9f1b',1,'conjunto']]],
  ['erase',['erase',['../classconjunto.html#a92332298c1202e92027b48f01c69ae91',1,'conjunto::erase(const long int &amp;id)'],['../classconjunto.html#a474a2f093c746797d5ece109849dfabd',1,'conjunto::erase(const crimen &amp;e)']]]
];
