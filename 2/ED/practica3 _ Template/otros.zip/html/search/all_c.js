var searchData=
[
  ['practica_20template',['PRACTICA TEMPLATE',['../index.html',1,'']]],
  ['primary_5ftype',['primary_type',['../classcrimen.html#ae6d5de0ba61dbebb13b78d0010907467',1,'crimen']]],
  ['prueba_2ecpp',['prueba.cpp',['../prueba_8cpp.html',1,'']]]
];
