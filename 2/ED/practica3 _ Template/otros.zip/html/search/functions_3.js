var searchData=
[
  ['fecha',['fecha',['../classfecha.html#a6775ef84b5838e12e28fd341793f4539',1,'fecha::fecha()'],['../classfecha.html#affbc58390398cbbc117bdfa754b0cd35',1,'fecha::fecha(const fecha &amp;F)'],['../classfecha.html#aed5c22d5eeb15f1f2927d5a2c28b74df',1,'fecha::fecha(const string &amp;s)']]],
  ['find',['find',['../classconjunto.html#a725ddba7aa25ad0576f13000e035ee6f',1,'conjunto::find(const long int &amp;id) const '],['../classconjunto.html#a72ee85a4309acdd8274392fc4a765de4',1,'conjunto::find(const crimen &amp;c)'],['../classconjunto.html#adc065d4751136dbf69b7b74bc7ca0684',1,'conjunto::find(const crimen &amp;c) const ']]],
  ['finddescr',['findDESCR',['../classconjunto.html#ab4f2fdce330e5b53c3ac8f529ccd435d',1,'conjunto']]],
  ['findiucr',['findIUCR',['../classconjunto.html#a076dc70516af91c07b570bca24c6d9f7',1,'conjunto']]]
];
