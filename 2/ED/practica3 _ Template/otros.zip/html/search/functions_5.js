var searchData=
[
  ['insert',['insert',['../classconjunto.html#ab908ba4bc5923ce8617bd1003bcf08e9',1,'conjunto']]],
  ['iterator',['iterator',['../classconjunto_1_1iterator.html#a3f22236830d397ec750b795e4358492d',1,'conjunto::iterator::iterator()'],['../classconjunto_1_1iterator.html#ae6ffce98c8835de978c7b8f0a769a1fe',1,'conjunto::iterator::iterator(const iterator &amp;it)']]]
];
