var searchData=
[
  ['latitude',['latitude',['../classcrimen.html#a1ecd1bcebba3566f13a469ec82f647a0',1,'crimen']]],
  ['lecturas',['lecturas',['../prueba_8cpp.html#a5644b175946e8de0d5f8f8bd2f35d90d',1,'prueba.cpp']]],
  ['location',['location',['../classcrimen.html#acca87eb25a97e33dad2346209bee3c91',1,'crimen']]],
  ['longitude',['longitude',['../classcrimen.html#ac140577426c2a38d58ec1907bce53492',1,'crimen']]]
];
