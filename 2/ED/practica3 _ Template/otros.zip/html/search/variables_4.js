var searchData=
[
  ['id',['ID',['../classcrimen.html#a59702f88f0b0c25781ae3d296790dcb8',1,'crimen']]],
  ['itv',['itv',['../classconjunto_1_1iterator.html#a670501cc6724497877d7a131efe50e60',1,'conjunto::iterator']]],
  ['iucr',['IUCR',['../classcrimen.html#a064e0e02109feaea19f254ef47a2510c',1,'crimen']]]
];
